//   Linked-List - Implementation in Visual C++
//8: Delete a Node at Last in a Singly-Linked-List 

#include <iostream>
#include "SinglyLinkedList.cpp"
using namespace std;
using namespace LinkedList;

int main() {

	SLL obj;

	string name;
	int length;
	cout << "Enter Total Number of Nodes : ";
	cin >> length;
	for (int i = 0; i < length; i++)
	{
		cout << "Enter Name " << i + 1 << " : ";
		cin >> name;
		obj.AddNodes(name);
	}
	obj.DisplayNodes();
	obj.DeleteNodeAtLast();
	cout << "After Last Node Deletion ..." << endl;
	obj.DisplayNodes();



	system("pause");
	return 0;
}