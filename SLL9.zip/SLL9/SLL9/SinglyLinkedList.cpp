#include <iostream>
#include <string>
using namespace std;

namespace LinkedList
{
	struct Node
	{
		string name;
		Node *link;
	};

	class SLL
	{
		private:
			Node * start, *temp, *current;
		public:
			SLL() {
				start = NULL;
				temp = NULL;
				current = NULL;
			}
			// Insertion in SLL
			void InsertNodes(string _name) {
				temp = new Node;
				temp->name = _name;
				temp->link = NULL;
				if (start == NULL)
					start = temp;
				else
				{
					current = start;
					while (current->link != NULL)
						current = current->link;
					current->link = temp;
				}
			}
			// Searching in SLL
			void SearchNode(string _name) {
				current = start;
				for (int i = 0; current != NULL ; i++)
				{
					if (current->name == _name) {
						cout << "Name " << current->name << " found at Location " << i+1 << endl;
						return;
					}
					current = current->link;
				}
				cout << "Name not found!" << endl;
			}
			// Traversing in SLL
			void DisplayNodes() {
				current = start;
				cout << "List elements are : ";
				while (current != NULL)
				{
					cout << current->name << " ";
					current = current->link;
				}
				cout << endl;
			}
	};
}
