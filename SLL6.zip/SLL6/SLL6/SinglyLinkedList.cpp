#include <iostream>
#include <string>
using namespace std;

namespace LinkedList
{
	struct Node
	{
		string name;
		Node *link;
	};

	class SLL
	{
		private:
			Node * start, *temp, *current;
		public:
			SLL() {
				start = NULL;
				temp = NULL;
				current = NULL;
			}
			// Create a Singly-Linked-List
			void AddNodes(string _name) {
				temp = new Node;
				temp->name = _name;
				temp->link = NULL;
				if (start == NULL)
					start = temp;
				else
				{
					current = start;
					while (current->link != NULL)
						current = current->link;
					current->link = temp;
				}
			}
			// Insertion at a Specified Location in SLL
			void InsertNode(string _name, int pos) {
				temp = new Node;
				temp->name = _name;
				// Go to the specified position 
				current = start;
				for (int i = 1; i < pos-1; i++){
					current = current->link;
					if (current == NULL) {
						cout << "Invalid Position";
						return;
					}
				}
				// Insert Node in SLL
				if (pos == 1) {
					temp->link = start;
					start = temp;
					return;
				}
				temp->link = current->link;
				current->link = temp;
			}
			// Traversing in SLL
			void DisplayNodes() {
				current = start;
				cout << "List elements are : ";
				while (current != NULL)
				{
					cout << current->name << " ";
					current = current->link;
				}
				cout << endl;
			}
	};
}
