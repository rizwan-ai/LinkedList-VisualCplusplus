//   Linked-List - Implementation in Visual C++
//6: Insert a Node at any specified location in a Singly-Linked-List 

#include <iostream>
#include "SinglyLinkedList.cpp"
using namespace std;
using namespace LinkedList;

int main() {

	SLL obj;

	string name;
	int length;
	cout << "Enter Total Number of Nodes : ";
	cin >> length;
	for (int i = 0; i < length; i++)
	{
		cout << "Enter Name " << i + 1 << " : ";
		cin >> name;
		obj.AddNodes(name);
	}
	obj.DisplayNodes();
	cout << "Enter new Name to Insert : ";
	cin >> name;
	int position;
	cout << "Enter position in List : ";
	cin >> position;
	obj.InsertNode(name, position);
	cout << "After Insertion ..." << endl;
	obj.DisplayNodes();

	

	system("pause");
	return 0;
}