#include <iostream>
using namespace std;

namespace LinkedList
{
	struct Node
	{
		char name[20];
		Node *link;
	};

	class SLL
	{
		private:
			Node * start, *temp;
		public:
			SLL() {
				start = NULL;
				temp = NULL;
			}
			// Insertion in SLL
			void InsertNodes(char _name[]) {
				temp = new Node;
				strcpy_s(temp->name, _name);  
				temp->link = start;  
				start = temp;
			}
			// Traversing in SLL
			void DisplayNodes() {
				temp = start;
				cout << "List is : ";
				while (temp != NULL)
				{
					cout << temp->name << " ";
					temp = temp->link;
				}
				cout << endl;
			}
	};
}


// Visual C++ : strcpy_s, wcscpy_s, _mbscpy_s
// https://docs.microsoft.com/en-us/cpp/c-runtime-library/reference/strcpy-s-wcscpy-s-mbscpy-s?view=vs-2017