//   Linked-List - Implementation in Visual C++
//3: Insert many Nodes at the beginning of a Singly-Linked-List

#include <iostream>
#include "SinglyLinkedList.cpp"
using namespace std;
using namespace LinkedList;

int main() {

	SLL obj;

	char name[20];
	int n;
	cout << "Enter Total Number of Nodes : ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "Enter Name " << i + 1 << " : ";
		cin >> name;
		obj.InsertNodes(name);
		obj.DisplayNodes();
	}

	system("pause");
	return 0;
}