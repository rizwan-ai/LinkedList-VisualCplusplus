#include <iostream>
#include <string>
using namespace std;

namespace LinkedList
{
	struct Node
	{
		string name;
		Node *link;
	};

	class SLL
	{
		private:
			Node * start, *temp, *current;
		public:
			SLL() {
				start = NULL;
				temp = NULL;
				current = NULL;
			}
			// Insertion in SLL
			void InsertNodes(string _name) {
				temp = new Node;
				temp->name = _name;
				temp->link = NULL;
				if (start == NULL)
					start = temp;
				else
				{
					current = start;
					while (current->link != NULL)
						current = current->link;
					current->link = temp;
				}
			}
			// Searching in SLL
			void SearchNode(string _name) {
				if (start == NULL) {
					return;
				}
				current = start;
				int i = 0;
				while(current != NULL)
				{
					i++;
					if (current->name == _name) {
						cout << "Name " << current->name << " found at Location " << i << endl;
						return;
					}
					current = current->link;
				}
				cout << "Name not found!" << endl;
			}
			// Deletion in SLL
			void DeleteNode(string _name) {
				if (start == NULL) {
					return;
				}
				current = temp = start;
				if (current->name == _name) {
					temp = start;
					start = start->link;
					delete temp;
					cout << "Name found and deleted!" << endl;
					return;
				}
				while(current != NULL)
				{
					if (current->name == _name) {
						temp->link = current->link;
						delete current;
						cout << "Name found and deleted!" << endl;
						return;
					}
					temp = current;
					current = current->link;
				}
				cout << "Name not found!" << endl;
			}
			// Traversing in SLL
			void DisplayNodes() {
				if (start == NULL) {
					cout << "List is Empty!" << endl;
					return;
				}
				current = start;
				cout << "List elements are : ";
				while (current != NULL)
				{
					cout << current->name << " ";
					current = current->link;
				}
				cout << endl;
			}
	};
}
