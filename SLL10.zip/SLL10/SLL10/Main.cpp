//   Linked-List - Implementation in Visual C++
//10: Delete a Node at any specified location in a Singly-Linked-List  

#include <iostream>
#include "SinglyLinkedList.cpp"
using namespace std;
using namespace LinkedList;

int main() {

	SLL obj;

	string name;
	int length;
	cout << "Enter Total Number of Nodes : ";
	cin >> length;

	for (int i = 0; i < length; i++)
	{
		cout << "Enter Name " << i + 1 << " : ";
		cin >> name;
		obj.InsertNodes(name);
	}
	obj.DisplayNodes();

	cout << "Enter Name for search : ";
	cin >> name;
	obj.SearchNode(name);

	cout << "Enter Name for delete : ";
	cin >> name;
	obj.DeleteNode(name);

	cout << "\n";
	obj.DisplayNodes();

	system("\npause");
	return 0;
}