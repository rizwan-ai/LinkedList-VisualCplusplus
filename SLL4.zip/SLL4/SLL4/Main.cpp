//   Linked-List - Implementation in Visual C++
//4: Insert a one Node at the end of a Singly-Linked-List

#include <iostream>
#include "SinglyLinkedList.cpp"
using namespace std;
using namespace LinkedList;

int main() {

	SLL obj;

	string name;

	for (int i = 0; i < 2; i++)
	{
		cout << "Enter Name " << i + 1 << " : ";
		cin >> name;
		obj.InsertNodesAtEnd(name);
		obj.DisplayNodes();
	}

	system("pause");
	return 0;
}