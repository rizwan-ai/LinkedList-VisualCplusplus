#include <iostream>
#include <string>
using namespace std;

namespace LinkedList
{
	struct Node
	{
		string name;
		Node *link;
	};

	class SLL
	{
		private:
			Node * start, *temp, *current;
		public:
			SLL() {
				start = NULL;
				temp = NULL;
				current = NULL;
			}
			// Insertion in SLL
			void InsertNodesAtEnd(string _name) {
				temp = new Node;
				temp->name = _name;
				temp->link = NULL;
				if (start == NULL)
					start = temp;
				else
				{
					current = start;
					while (current->link != NULL)
						current = current->link;
					current->link = temp;
				}
			}
			// Traversing in SLL
			void DisplayNodes() {
				current = start;
				cout << "List elements are : ";
				while (current != NULL)
				{
					cout << current->name << " ";
					current = current->link;
				}
				cout << endl;
			}
	};
}
